
# from flask import Flask, render_template, request, redirect, url_for
# import pandas as pd
# import matplotlib.pyplot as plt
# import random
# from datetime import datetime, timedelta

# app = Flask(__name__)

# # Synthetic data
# synthetic_pre_drm = [random.uniform(1.0, 3.0) for _ in range(24)]
# synthetic_post_drm = [random.uniform(0.5, 2.5) for _ in range(24)]
# synthetic_timestamps = pd.date_range("2023-01-01", periods=24, freq="H")

# # Home Route
# @app.route('/')
# def home():
#     return render_template('home.html')

# # Energy Consumption Route with User Input
# @app.route('/energy_consumption', methods=['GET', 'POST'])
# def energy_consumption():
#     if request.method == 'POST':
#         pre_drm = request.form.getlist('pre_drm')
#         print(pre_drm)
#         pre_drm=pre_drm[0].split(',')
#         pre_drm=[float(i) for i in pre_drm]
#         post_drm = request.form.getlist('post_drm')
#         post_drm=post_drm[0].split(',')
#         post_drm=[float(i) for i in post_drm]
#         timestamps = pd.date_range("2023-01-01", periods=len(pre_drm), freq="H")
#         data = pd.DataFrame({'timestamp': timestamps, 'pre_drm': pre_drm, 'post_drm': post_drm})

#         # Combine synthetic and user data
#         user_data = pd.DataFrame({'timestamp': timestamps, 'pre_drm': pre_drm, 'post_drm': post_drm})
#         combined_data = pd.concat([data, user_data])

#         combined_data.plot(x='timestamp', y=['pre_drm', 'post_drm'])
#         plt.title('Energy Consumption Patterns')
#         plt.xlabel('Time')
#         plt.ylabel('Energy Consumption (kWh)')
#         plt.savefig('static/energy_consumption.png')
#         plt.close()  # Close the plot to avoid overlapping

#         return render_template('energy_consumption.html', image_url='static/energy_consumption.png', synthetic_data=(synthetic_timestamps, synthetic_pre_drm, synthetic_post_drm), user_data=(timestamps, pre_drm, post_drm))
    
#     return render_template('energy_consumption_form.html')

# # Blockchain Transaction Route
# @app.route('/blockchain_transactions', methods=['GET', 'POST'])
# def blockchain_transactions():
#     if request.method == 'POST':
#         sender = request.form['sender']
#         recipient = request.form['recipient']
#         amount = request.form['amount']
#         timestamp = request.form['timestamp']
#         transaction = {"sender": sender, "recipient": recipient, "amount": amount, "timestamp": timestamp}
        
#         # Adding synthetic transaction
#         synthetic_transaction = {
#             "sender": "SyntheticUser",
#             "recipient": "GridOperator",
#             "amount": random.uniform(50, 150),
#             "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#         }

#         transactions = [transaction, synthetic_transaction]  # Store both transactions
#         return render_template('blockchain_transactions.html', transactions=transactions)

#     return render_template('blockchain_transaction_form.html')

# # Grid Stability Route with User Input
# @app.route('/grid_stability', methods=['GET', 'POST'])
# def grid_stability():
#     if request.method == 'POST':
#         voltage_pre = request.form.getlist('voltage_pre')
#         voltage_post = request.form.getlist('voltage_post')
#         voltage_pre=voltage_pre[0].split(',')
#         voltage_pre=[int(i) for i in voltage_pre]
#         voltage_post=voltage_post[0].split(',')
#         voltage_post=[int(i) for i in voltage_post]
#         timestamps = pd.date_range("2023-01-01", periods=len(voltage_pre), freq="H")
#         data = pd.DataFrame({'timestamp': timestamps, 'voltage_pre': voltage_pre, 'voltage_post': voltage_post})

#         # Combine synthetic and user data
#         synthetic_voltage_pre = [random.uniform(220, 240) for _ in range(24)]
#         synthetic_voltage_post = [random.uniform(215, 235) for _ in range(24)]
#         synthetic_data = pd.DataFrame({'timestamp': synthetic_timestamps, 'voltage_pre': synthetic_voltage_pre, 'voltage_post': synthetic_voltage_post})

#         combined_data = pd.concat([data, synthetic_data])

#         combined_data.plot(x='timestamp', y=['voltage_pre', 'voltage_post'])
#         plt.title('Grid Voltage Stability')
#         plt.xlabel('Time')
#         plt.ylabel('Voltage (V)')
#         plt.savefig('static/grid_stability.png')
#         plt.close()  # Close the plot to avoid overlapping

#         return render_template('grid_stability.html', image_url='static/grid_stability.png')
    
#     return render_template('grid_stability_form.html')

# # Consumer Participation Route with User Input
# @app.route('/consumer_participation', methods=['GET', 'POST'])
# def consumer_participation():
#     if request.method == 'POST':
#         participating = int(request.form['participating'])
#         non_participating = 100 - participating
#         labels = ['Participating', 'Non-Participating']
#         sizes = [participating, non_participating]

#         # Adding synthetic data
#         synthetic_participating = random.randint(50, 90)
#         synthetic_non_participating = 100 - synthetic_participating
#         sizes += [synthetic_participating, synthetic_non_participating]
#         labels += ['Synthetic Participating', 'Synthetic Non-Participating']

#         plt.pie(sizes, labels=labels, autopct='%1.1f%%')
#         plt.title('Consumer Participation in DRM')
#         plt.savefig('static/consumer_participation.png')
#         plt.close()  # Close the plot to avoid overlapping

#         return render_template('consumer_participation.html', image_url='static/consumer_participation.png')

#     return render_template('consumer_participation_form.html')

# # System Efficiency Route
# @app.route('/system_efficiency', methods=['GET', 'POST'])
# def system_efficiency():
#     if request.method == 'POST':
#         energy_saved = request.form['energy_saved']
#         cost_saved = request.form['cost_saved']
#         savings = {"Energy Saved (kWh)": energy_saved, "Cost Saved ($)": cost_saved}

#         # Adding synthetic data
#         synthetic_energy_saved = random.uniform(1000, 5000)
#         synthetic_cost_saved = random.uniform(100, 1000)
#         savings["Synthetic Energy Saved (kWh)"] = synthetic_energy_saved
#         savings["Synthetic Cost Saved ($)"] = synthetic_cost_saved

#         return render_template('system_efficiency.html', savings=savings)

#     return render_template('system_efficiency_form.html')

# if __name__ == '__main__':
#     app.run(debug=True)
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
import pandas as pd
import matplotlib.pyplot as plt
import random
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # For session management
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)

# Energy Data Model
class EnergyData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    timestamp = db.Column(db.String(100), nullable=False)
    pre_drm = db.Column(db.Float, nullable=False)
    post_drm = db.Column(db.Float, nullable=False)

# Initialize Database
with app.app_context():
    db.create_all()

# Home Route
@app.route('/')
@app.route('/home')
def home():
    if 'user_id' not in session:
        flash('Please log in to access this feature.', 'danger')
        return redirect(url_for('login'))
    if 'user_id' in session:
        username = session['username']
        return render_template('home.html', username=username)
    else:
        return render_template('register.html')

# Energy Consumption Route
@app.route('/energy_consumption', methods=['GET', 'POST'])
def energy_consumption():
    if 'user_id' not in session:
        flash('Please log in to access this feature.', 'danger')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        pre_drm = request.form.getlist('pre_drm')[0].split(',')
        post_drm = request.form.getlist('post_drm')[0].split(',')
        pre_drm = [float(i) for i in pre_drm]
        post_drm = [float(i) for i in post_drm]

        # Generate timestamps
        timestamps = pd.date_range("2023-01-01", periods=len(pre_drm), freq="H")

        # Save user data in database
        user_id = session['user_id']
        for i in range(len(pre_drm)):
            new_data = EnergyData(user_id=user_id, timestamp=str(timestamps[i]), pre_drm=pre_drm[i], post_drm=post_drm[i])
            db.session.add(new_data)
        db.session.commit()

        # Plot the data
        plt.plot(timestamps, pre_drm, label='Pre DRM')
        plt.plot(timestamps, post_drm, label='Post DRM')
        plt.title('Energy Consumption Patterns')
        plt.xlabel('Time')
        plt.ylabel('Energy Consumption (kWh)')
        plt.legend()
        plt.savefig('static/user_energy_consumption.png')
        plt.close()

        return render_template('energy_consumption.html', image_url='static/user_energy_consumption.png')

    return render_template('energy_consumption_form.html')

# Blockchain Transaction Route
@app.route('/blockchain_transactions', methods=['GET', 'POST'])
def blockchain_transactions():
    if 'user_id' not in session:
        flash('Please log in to access this feature.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        # Get user input
        sender = request.form['sender']
        recipient = request.form['recipient']
        amount = request.form['amount']
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        transaction = {"sender": sender, "recipient": recipient, "amount": amount, "timestamp": timestamp}
        
        # Create synthetic transaction
        synthetic_transaction = {
            "sender": "SyntheticUser",
            "recipient": "GridOperator",
            "amount": random.uniform(50, 150),
            "timestamp": timestamp
        }

        # Combine transactions
        transactions = [transaction, synthetic_transaction]

        # Save transactions to CSV
        transactions_df = pd.DataFrame(transactions)
        transactions_df.to_csv('transactions.csv', index=False)

        return render_template('blockchain_transactions.html', transactions=transactions)

    return render_template('blockchain_transaction_form.html')

# Grid Stability Route
@app.route('/grid_stability', methods=['GET', 'POST'])
def grid_stability():
    if 'user_id' not in session:
        flash('Please log in to access this feature.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        # Get user input
        voltage_pre = request.form.getlist('voltage_pre')[0].split(',')
        voltage_post = request.form.getlist('voltage_post')[0].split(',')
        voltage_pre = [int(i) for i in voltage_pre]
        voltage_post = [int(i) for i in voltage_post]

        # Generate timestamps and user data
        timestamps = pd.date_range("2023-01-01", periods=len(voltage_pre), freq="H")
        user_data = pd.DataFrame({'timestamp': timestamps, 'voltage_pre': voltage_pre, 'voltage_post': voltage_post})

        # Save user data to CSV
        user_data.to_csv('user_grid_stability.csv', index=False)

        # Plot combined data
        plt.plot(timestamps, voltage_pre, label='Voltage Pre')
        plt.plot(timestamps, voltage_post, label='Voltage Post')
        plt.title('Grid Voltage Stability')
        plt.xlabel('Time')
        plt.ylabel('Voltage (V)')
        plt.legend()
        plt.savefig('static/grid_stability.png')
        plt.close()

        return render_template('grid_stability.html', image_url='static/grid_stability.png')
    
    return render_template('grid_stability_form.html')

# Consumer Participation Route
@app.route('/consumer_participation', methods=['GET', 'POST'])
def consumer_participation():
    if 'user_id' not in session:
        flash('Please log in to access this feature.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        # Get user input
        participating = int(request.form['participating'])
        non_participating = 100 - participating
        labels = ['Participating', 'Non-Participating']
        sizes = [participating, non_participating]

        # Add synthetic data
        synthetic_participating = random.randint(50, 90)
        synthetic_non_participating = 100 - synthetic_participating
        sizes += [synthetic_participating, synthetic_non_participating]
        labels += ['Synthetic Participating', 'Synthetic Non-Participating']

        # Plot data
        plt.pie(sizes, labels=labels, autopct='%1.1f%%')
        plt.title('Consumer Participation in DRM')
        plt.savefig('static/consumer_participation.png')
        plt.close()

        return render_template('consumer_participation.html', image_url='static/consumer_participation.png')

    return render_template('consumer_participation_form.html')

# System Efficiency Route
@app.route('/system_efficiency', methods=['GET', 'POST'])
def system_efficiency():
    if request.method == 'POST':
        # Get user input
        energy_saved = float(request.form['energy_saved'])
        cost_saved = float(request.form['cost_saved'])
        savings = {"Energy Saved (kWh)": energy_saved, "Cost Saved ($)": cost_saved}

        # Add synthetic data
        synthetic_energy_saved = random.uniform(1000, 5000)
        synthetic_cost_saved = random.uniform(100, 1000)
        savings["Synthetic Energy Saved (kWh)"] = synthetic_energy_saved
        savings["Synthetic Cost Saved ($)"] = synthetic_cost_saved
        total_energy_savings=synthetic_energy_saved+energy_saved
        total_cost_savings=synthetic_cost_saved+cost_saved




        return render_template('system_efficiency.html', total_energy_savings=total_energy_savings,total_cost_savings=total_cost_savings)

    return render_template('system_efficiency_form.html')
from werkzeug.security import generate_password_hash, check_password_hash

# ...

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Hash the password for security (remove method parameter)
        hashed_password = generate_password_hash(password)

        # Check if the user already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('register'))

        # Create new user
        new_user = User(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# ...


# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Validate user credentials
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password', 'danger')

    return render_template('login.html')

# Logout Route
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
